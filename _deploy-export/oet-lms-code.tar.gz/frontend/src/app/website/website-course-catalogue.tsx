"use client";

/**
 * WebsiteCourseCatalogue — the homepage "Choose your material" section.
 * Visual design per oethq-section-final; prices/links stay DYNAMIC from the live
 * product catalogue + plans so admin price edits flow straight through.
 */
import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/api";
import { productsApi, type CatalogueProduct } from "@/lib/products-api";
import type { PlanDto } from "@/lib/types";
import "./oethq-material-section.css";

const money = (n: number) => `$${Number.isInteger(n) ? n : n.toFixed(2)}`;

export function WebsiteCourseCatalogue() {
  const [products, setProducts] = useState<CatalogueProduct[]>([]);
  const [plans, setPlans] = useState<PlanDto[]>([]);
  const [joined, setJoined] = useState<Record<string, boolean>>({});

  useEffect(() => {
    let active = true;
    void Promise.all([
      productsApi.list().then((r) => r.products).catch(() => [] as CatalogueProduct[]),
      apiFetch<PlanDto[]>("/plans", { token: null }).catch(() => [] as PlanDto[])
    ]).then(([p, pl]) => {
      if (!active) return;
      setProducts(p);
      setPlans(pl);
    });
    return () => { active = false; };
  }, []);

  const bySlug = (slug: string) => products.find((p) => p.slug === slug);
  const priceOf = (slug: string, fallback: number) => {
    const p = bySlug(slug);
    return p && p.price != null ? Number(p.price) : fallback;
  };
  const daysOf = (slug: string, fallback: number) => {
    const p = bySlug(slug);
    return p && p.durationDays != null ? p.durationDays : fallback;
  };

  const R = priceOf("reading", 99);
  const L = priceOf("listening", 99);
  const RL = priceOf("reading-listening", 149);
  const RLwas = R + L;
  const keep = Math.max(0, RLwas - RL);
  const readDays = daysOf("reading", 45);
  const listenDays = daysOf("listening", 45);
  const bothDays = daysOf("reading-listening", 45);
  // Writing Corrections is live — cheapest package sets the "from" price.
  const W = Math.min(
    priceOf("writing-corrections-2", 28),
    priceOf("writing-corrections-6", 77),
    priceOf("writing-corrections-12", 147)
  );

  const paidPlanPrices = plans.filter((pl) => pl.tier !== "STARTER" && (pl.isActive ?? true)).map((pl) => Number(pl.price)).filter((n) => n > 0);
  const completeFrom = paidPlanPrices.length ? Math.min(...paidPlanPrices) : 193;

  const onJoin = (product: string) => (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: POST { email, product } to a real waitlist provider.
    setJoined((prev) => ({ ...prev, [product]: true }));
  };

  return (
    <section className="ohq-section" aria-labelledby="ohq-heading">
      <div className="ohq-wrap">
        {/* HEADER */}
        <p className="ohq-eyebrow">More Ways To Prepare</p>
        <h2 className="ohq-h2" id="ohq-heading">Target the Skill That&apos;s <span>Costing You the B</span></h2>
        <p className="ohq-sub">Most candidates don&apos;t fail OET across the board — they lose the grade in one or two sections. Go all-in with a Complete Course, or take the material for exactly where you drop marks.</p>

        {/* FLAGSHIP */}
        <div className="ohq-plate">
          <div>
            <span className="ohq-plate-pill">Most Complete · All Four Skills</span>
            <h3>OET Complete Courses</h3>
            <div className="ohq-eng-bar">
              <span className="ohq-eng-ico"><svg viewBox="0 0 24 24"><path d="M13 2L3 14h7l-1 8 10-12h-7z" /></svg></span>
              <b><i>2026</i> CBLA-Calibrated · All Four Skills</b>
              <span className="ohq-new">New</span>
            </div>
            <p className="ohq-plate-p">Lectures, corrections and the clearance prediction that tells you when you&apos;re actually ready to book the exam — sat on the portal, under the real exam clock.</p>
            <div className="ohq-stats">
              <div className="ohq-stat"><b>15 + 15</b><span>OET HQ mock tests</span></div>
              <div className="ohq-stat"><b>10 + 10</b><span>OET HQ past papers</span></div>
              <div className="ohq-stat"><b>15</b><span>Writing corrections</span></div>
              <div className="ohq-stat"><b>Live</b><span>Clearance prediction</span></div>
              <div className="ohq-stat"><b>Flexible</b><span>Live cohort classes</span></div>
              <div className="ohq-stat"><b>60 days</b><span>Material refresh</span></div>
            </div>
            <p className="ohq-plate-out">
              <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12" /></svg>
              <span>Our 2026 mocks <em>+</em> OET HQ past papers — everything you need to clear all four skills on the first attempt.</span>
            </p>

            <div className="ohq-plate-live">
              <div className="ohq-plate-live-head">
                <span className="ohq-live-dot" aria-hidden />
                <b>Live daily practice — included in every Complete Course</b>
              </div>
              <ul className="ohq-plate-live-list">
                {PLATE_LIVE.map((t, i) => (
                  <li key={t} style={{ ["--i" as string]: i } as React.CSSProperties}>
                    <span className="ohq-plive-ico" aria-hidden><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5" /></svg></span>
                    <span className="ohq-plive-t">{t}</span>
                    <span className="ohq-plive-badge" aria-hidden>LIVE</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div className="ohq-plate-buy">
            <p className="ohq-from">Packages from</p>
            <p className="ohq-plate-price"><sup>US$</sup>{completeFrom}</p>
            <p className="ohq-plate-note"><b style={{ color: "#fff" }}>4 months of access</b> · three tiers · upgrade anytime</p>
            <a className="ohq-btn ohq-btn--gold" href="/courses">
              See the packages
              <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
            </a>
          </div>
        </div>

        <div className="ohq-divider"><span>Or take one skill on its own</span></div>

        {/* MATERIAL CARDS */}
        <div className="ohq-grid">
          {/* Reading */}
          <article className="ohq-card">
            <div className="ohq-icon">
              <svg viewBox="0 0 24 24"><path d="M2 4h7a3 3 0 013 3v13a2.5 2.5 0 00-2.5-2.5H2z" /><path d="M22 4h-7a3 3 0 00-3 3v13a2.5 2.5 0 012.5-2.5H22z" /></svg>
            </div>
            <h3>OET Reading Material</h3>
            <p className="ohq-promise">For candidates who <b>run out of time in Part C</b> and guess the last six answers.</p>
            <Engine label="Everything you need to clear Reading on the first attempt" />
            <ul className="ohq-list">
              <li>Time-flexible live cohort classes</li>
              <li>Part A, B and C strategy taught separately</li>
              <li>Reading progress report after every attempt</li>
            </ul>
            <Included items={INC_READING} />
            <div className="ohq-foot">
              <div className="ohq-price-row">
                <span className="ohq-price"><sup>$</sup>{R}</span>
                <span className="ohq-onetime">One-time</span>
              </div>
              <AccessLine days={readDays} />
              <a className="ohq-btn ohq-btn--ghost" href="/courses/reading">
                Get Reading material
                <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
              </a>
            </div>
          </article>

          {/* Reading + Listening — FEATURED */}
          <article className="ohq-card ohq-card--hero">
            <span className="ohq-badge">★ Most Chosen</span>
            <div className="ohq-icon">
              <svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5z" /><path d="M2 17l10 5 10-5" /><path d="M2 12l10 5 10-5" /></svg>
            </div>
            <h3>OET Reading &amp; Listening Material</h3>
            <p className="ohq-promise">The two receptive skills where <b>most candidates lose their B</b> — trained together, in one system.</p>
            <Engine label="Everything you need to clear both papers on the first attempt" />
            <ul className="ohq-list">
              <li>Time-flexible live cohort classes for both skills</li>
              <li>Everything in both single-skill materials</li>
              <li>Full lecture series for Reading and Listening</li>
              <li>Combined progress report across R + L</li>
            </ul>
            <Included items={INC_BOTH} />
            <div className="ohq-foot">
              <div className="ohq-price-row">
                <span className="ohq-price"><sup>$</sup>{RL}</span>
                {RLwas > RL ? <span className="ohq-was">{money(RLwas)}</span> : null}
                <span className="ohq-onetime">One-time</span>
              </div>
              <AccessLine days={bothDays} />
              <a className="ohq-btn ohq-btn--white" href="/courses/reading-listening">
                Get both skills
                <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
              </a>
            </div>
          </article>

          {/* Listening */}
          <article className="ohq-card">
            <div className="ohq-icon">
              <svg viewBox="0 0 24 24"><path d="M3 17v-5a9 9 0 0118 0v5" /><path d="M21 18a2 2 0 01-2 2h-1v-6h1a2 2 0 012 2zM3 18a2 2 0 002 2h1v-6H5a2 2 0 00-2 2z" /></svg>
            </div>
            <h3>OET Listening Material</h3>
            <p className="ohq-promise">For candidates who <b>lose Part A on spelling</b> and get caught by Part C distractors.</p>
            <Engine label="Everything you need to clear Listening on the first attempt" />
            <ul className="ohq-list">
              <li>Time-flexible live cohort classes</li>
              <li>Part A, B and C strategy taught separately</li>
              <li>Listening progress report after every attempt</li>
            </ul>
            <Included items={INC_LISTENING} />
            <div className="ohq-foot">
              <div className="ohq-price-row">
                <span className="ohq-price"><sup>$</sup>{L}</span>
                <span className="ohq-onetime">One-time</span>
              </div>
              <AccessLine days={listenDays} />
              <a className="ohq-btn ohq-btn--ghost" href="/courses/listening">
                Get Listening material
                <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
              </a>
            </div>
          </article>
        </div>

        {/* WRITING CORRECTIONS — LIVE flagship */}
        <div className="ohq-writing-live">
          <span className="ohq-wl-spark" aria-hidden />
          <div className="ohq-wl-main">
            <div className="ohq-wl-head">
              <span className="ohq-wl-icon" aria-hidden>
                <svg viewBox="0 0 24 24"><path d="M17 3a2.83 2.83 0 114 4L7.5 20.5 2 22l1.5-5.5z" /></svg>
              </span>
              <span className="ohq-wl-badge"><i className="ohq-wl-dot" aria-hidden />Live now</span>
              <span className="ohq-wl-new">New</span>
            </div>
            <h3>OET Writing Corrections</h3>
            <p className="ohq-wl-promise">
              Examiner-style corrections on your referral letters — marked line by line against the <b>official OET Writing criteria</b>, by a human. Available standalone, no Complete Course required.
            </p>
            <ul className="ohq-wl-list">
              {[
                "2, 6 or 12-letter correction packages",
                "Marked to every official OET Writing criterion",
                "Per-profession case notes + your letter history"
              ].map((t, i) => (
                <li key={t} style={{ ["--i" as string]: i } as React.CSSProperties}>
                  <span className="ohq-wl-check" aria-hidden><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5" /></svg></span>
                  {t}
                </li>
              ))}
            </ul>
          </div>
          <div className="ohq-wl-buy">
            <p className="ohq-wl-from">From</p>
            <p className="ohq-wl-price"><sup>$</sup>{W}</p>
            <p className="ohq-wl-sub">2 · 6 · 12 letters</p>
            <a className="ohq-btn ohq-btn--gold ohq-wl-cta" href="/courses/writing-corrections">
              See correction packages
              <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
            </a>
          </div>
        </div>

        {/* BUNDLE LEDGER */}
        <div className="ohq-ledger">
          <div>
            <p className="ohq-ledger-label">Bought separately</p>
            <div className="ohq-eq">
              <div className="ohq-eq-item"><b>{money(R)}</b><span>Reading</span></div>
              <div className="ohq-op">+</div>
              <div className="ohq-eq-item"><b>{money(L)}</b><span>Listening</span></div>
              <div className="ohq-op">=</div>
              <div className="ohq-eq-item ohq-crossed"><b>{money(RLwas)}</b><span>Separate total</span></div>
            </div>
          </div>
          <div className="ohq-ledger-out">
            <div className="ohq-ledger-price">
              <b>{money(RL)}</b>
              <span>Both skills together</span>
            </div>
            <div className="ohq-seal">
              <b>{money(keep)}</b>
              <span>You keep</span>
            </div>
          </div>
        </div>

        {/* COMING SOON */}
        <div className="ohq-next">
          <div className="ohq-next-head">
            <h3>Coming soon</h3>
            <p>Waitlist members get first access and launch pricing.</p>
          </div>
          <div className="ohq-next-grid">
            <WaitCard
              product="speaking"
              icon={<svg viewBox="0 0 24 24"><rect x="9" y="2" width="6" height="11" rx="3" /><path d="M5 10v1a7 7 0 0014 0v-1M12 18v4" /></svg>}
              title="OET Speaking Role Plays"
              body="Guided role-play practice against real exam cue cards, with structured feedback on the criteria examiners actually score you on."
              joined={Boolean(joined.speaking)}
              onJoin={onJoin("speaking")}
            />
            <aside className="ohq-now">
              <span className="ohq-now-pill">Available today</span>
              <h4>Prefer your writing corrections bundled in?</h4>
              <p>Every Complete Course package already includes human writing corrections — Foundation, Precision and Elite, no add-on needed.</p>
              <div className="ohq-now-nums">
                <div className="ohq-now-num"><b>3</b><span>Foundation</span></div>
                <div className="ohq-now-num"><b>7</b><span>Precision</span></div>
                <div className="ohq-now-num"><b>15</b><span>Elite</span></div>
              </div>
              <a className="ohq-btn ohq-btn--gold" href="/courses" style={{ width: "100%", marginTop: "auto" }}>
                See the packages
                <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
              </a>
            </aside>
          </div>
        </div>
      </div>
    </section>
  );
}

type IncItem = { t: string; live?: boolean };

/** Animated "Included free" strip — staggered reveal, pulsing dots on live items. */
function Included({ items }: { items: IncItem[] }) {
  return (
    <div className="ohq-inc">
      <span className="ohq-inc-h">
        <svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5" /></svg>
        Included free
      </span>
      <ul className="ohq-inc-list">
        {items.map((it, i) => (
          <li key={it.t} style={{ ["--i" as string]: i } as React.CSSProperties}>
            <span className={"ohq-inc-dot" + (it.live ? " live" : "")} aria-hidden />
            <span className="ohq-inc-t">{it.t}</span>
            {it.live ? <span className="ohq-inc-live" aria-hidden>LIVE</span> : null}
          </li>
        ))}
      </ul>
    </div>
  );
}

const INC_READING: IncItem[] = [
  { t: "Cheatsheets — Reading Part C" },
  { t: "Live Skimming & Scanning Exercise", live: true },
  { t: "Daily Live Articles from official OET Part C sources", live: true }
];
const INC_LISTENING: IncItem[] = [
  { t: "Cheatsheets — Listening Part C" },
  { t: "Daily Live Spelling Checker from OET Spelling Bank", live: true },
  { t: "Daily Live Podcasts from official OET Listening sources", live: true }
];
/** Standout live-features showcase for the flagship Complete Courses plate. */
const PLATE_LIVE: string[] = [
  "Cheatsheets — Reading & Listening Part C",
  "Daily Live Spelling Checker from OET Spelling Bank",
  "Live Skimming & Scanning Exercise",
  "Daily Live Articles from official OET Part C sources",
  "Daily Live Podcasts from official OET Listening sources"
];

const INC_BOTH: IncItem[] = [
  { t: "Cheatsheets — Reading & Listening Part C" },
  { t: "Daily Live Spelling Checker from OET Spelling Bank", live: true },
  { t: "Live Skimming & Scanning Exercise", live: true },
  { t: "Daily Live Articles from official OET Part C sources", live: true },
  { t: "Daily Live Podcasts from official OET Listening sources", live: true }
];

function Engine({ label }: { label: string }) {
  return (
    <div className="ohq-engine">
      <div className="ohq-eng-head">
        <span className="ohq-eng-ico"><svg viewBox="0 0 24 24"><path d="M13 2L3 14h7l-1 8 10-12h-7z" /></svg></span>
        <b><i>2026</i> CBLA-Calibrated</b>
        <span className="ohq-new">New</span>
      </div>
      <div className="ohq-formula">
        <span className="ohq-f"><b>OET HQ</b><span>Mock tests</span></span>
        <span className="ohq-plus" aria-hidden><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" /></svg></span>
        <span className="ohq-f"><b>OET HQ</b><span>Past papers</span></span>
      </div>
      <p className="ohq-eng-out">
        <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12" /></svg>
        {label}
      </p>
      <div className="ohq-eng-foot">
        <span className="ohq-chip"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" /></svg>On-portal exam clock</span>
        <span className="ohq-chip"><svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2" /><path d="M8 21h8M12 17v4" /></svg>Real exam interface</span>
        <span className="ohq-chip"><svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 11-3-6.7" /><path d="M21 3v5h-5" /></svg>Refreshed every 60 days</span>
      </div>
    </div>
  );
}

function AccessLine({ days }: { days: number }) {
  return (
    <p className="ohq-access">
      <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 11h18" /></svg>
      <b>{days} days</b> of access
    </p>
  );
}

function WaitCard({
  product, icon, title, body, joined, onJoin
}: {
  product: string; icon: React.ReactNode; title: string; body: string;
  joined: boolean; onJoin: (e: React.FormEvent) => void;
}) {
  return (
    <article className="ohq-wait">
      <div className="ohq-wait-top">
        <div className="ohq-wait-icon">{icon}</div>
        <span className="ohq-pill"><i className="ohq-dot" />Coming soon</span>
      </div>
      <h4>{title}</h4>
      <p>{body}</p>
      <div className="ohq-meta">
        <svg viewBox="0 0 24 24"><path d="M12 6v6l4 2" /><circle cx="12" cy="12" r="10" /></svg>
        Waitlist opens first · limited first intake
      </div>
      {joined ? (
        <div className="ohq-done">You&apos;re on the list — we&apos;ll email you the moment it opens.</div>
      ) : (
        <form className="ohq-form" onSubmit={onJoin}>
          <input type="email" required placeholder="Your email" aria-label={`Email for ${title} waitlist`} />
          <button type="submit">Notify me</button>
        </form>
      )}
    </article>
  );
}
