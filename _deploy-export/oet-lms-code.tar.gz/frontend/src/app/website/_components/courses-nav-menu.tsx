"use client";

/**
 * CoursesNavMenu — premium Courses dropdown for the website header.
 * Desktop: opens on hover (with close-intent delay so it never closes while the
 * pointer moves from trigger to panel) AND on click/focus; Escape + outside-click
 * close it. Mobile: the same markup renders as a tap-expand accordion inside the
 * burger drawer (hover is inert on touch). Data comes from the live /products
 * catalogue; locked products are shown but not clickable.
 */
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { BookOpen, ChevronDown, Headphones, Layers, Lock, Mic, PenLine } from "lucide-react";
import { productsApi, type CatalogueProduct } from "@/lib/products-api";

function SkillIcon({ product }: { product: CatalogueProduct }) {
  const s = product.includedSkills;
  const cls = "hp-cmenu-ic";
  if (product.slug === "reading-listening") return <Layers className={cls} aria-hidden />;
  if (s.includes("WRITING")) return <PenLine className={cls} aria-hidden />;
  if (s.includes("SPEAKING")) return <Mic className={cls} aria-hidden />;
  if (s.length === 1 && s[0] === "READING") return <BookOpen className={cls} aria-hidden />;
  if (s.length === 1 && s[0] === "LISTENING") return <Headphones className={cls} aria-hidden />;
  return <Layers className={cls} aria-hidden />;
}

const SKILL_MARKS: { key: string; label: string; Icon: typeof BookOpen }[] = [
  { key: "READING", label: "Reading", Icon: BookOpen },
  { key: "LISTENING", label: "Listening", Icon: Headphones },
  { key: "WRITING", label: "Writing", Icon: PenLine },
  { key: "SPEAKING", label: "Speaking", Icon: Mic }
];

export function CoursesNavMenu({ onNavigate }: { onNavigate?: () => void }) {
  const [open, setOpen] = useState(false);
  const [products, setProducts] = useState<CatalogueProduct[]>([]);
  const [hovered, setHovered] = useState<CatalogueProduct | null>(null);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  // Which skill marks light up, and in which variant, for the hovered course.
  const markClass = (skill: string) => {
    if (!hovered || !hovered.includedSkills.includes(skill)) return "hp-skmark";
    return hovered.category === "COMPLETE" ? "hp-skmark on-all" : "hp-skmark on";
  };

  useEffect(() => {
    let active = true;
    productsApi.list().then((r) => { if (active) setProducts(r.products); }).catch(() => undefined);
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    const onDown = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("mousedown", onDown);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("mousedown", onDown);
    };
  }, [open]);

  const openNow = () => {
    if (closeTimer.current) { clearTimeout(closeTimer.current); closeTimer.current = null; }
    setOpen(true);
  };
  const closeSoon = () => {
    closeTimer.current = setTimeout(() => setOpen(false), 140);
  };
  const navigate = () => { setOpen(false); onNavigate?.(); };

  const complete = products.find((p) => p.category === "COMPLETE");
  const standalone = products.filter((p) => p.category !== "COMPLETE");

  return (
    <div className="hp-courses" ref={wrapRef} onMouseEnter={openNow} onMouseLeave={closeSoon}>
      <button
        type="button"
        className="hp-courses-trigger"
        aria-haspopup="true"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        Courses
        <ChevronDown className={`hp-courses-chev${open ? " up" : ""}`} aria-hidden />
      </button>

      <div
        className={`hp-courses-panel${open ? " open" : ""}`}
        role="menu"
        aria-label="Courses"
        onMouseLeave={() => setHovered(null)}
      >
        {/* Skill-coverage matrix — sits first; hover a course below and the skills it covers light up. */}
        <div className="hp-cmenu-skills" aria-hidden>
          <span className="hp-cmenu-skills-q">Which skills do you need?</span>
          <span className="hp-cmenu-skmarks">
            {SKILL_MARKS.map(({ key, label, Icon }) => (
              <span key={key} className={markClass(key)} title={label}>
                <Icon aria-hidden />
              </span>
            ))}
          </span>
        </div>

        {complete && (
          <Link
            href={complete.landingRoute || "/courses"}
            className="hp-cmenu-complete"
            role="menuitem"
            onClick={navigate}
            onMouseEnter={() => setHovered(complete)}
          >
            <span className="hp-cmenu-complete-tag">Most complete</span>
            <span className="hp-cmenu-complete-title">{complete.name}</span>
            <span className="hp-cmenu-complete-desc">{complete.shortDescription}</span>
          </Link>
        )}

        <div className="hp-cmenu-divider"><span>Focused courses</span></div>

        <ul className="hp-cmenu-list">
          {standalone.map((p) => {
            const locked = p.status === "COMING_SOON" || !p.landingRoute;
            const inner = (
              <>
                <span className="hp-cmenu-ic-wrap" aria-hidden><SkillIcon product={p} /></span>
                <span className="hp-cmenu-item-body">
                  <span className="hp-cmenu-item-name">
                    {p.name}
                    {locked && <span className="hp-cmenu-soon">Coming soon</span>}
                  </span>
                  <span className="hp-cmenu-item-desc">{p.shortDescription}</span>
                </span>
                {locked ? (
                  <Lock className="hp-cmenu-lock" aria-hidden />
                ) : (
                  <span className="hp-cmenu-arrow" aria-hidden>→</span>
                )}
              </>
            );
            return (
              <li key={p.slug} role="none" onMouseEnter={() => setHovered(p)}>
                {locked ? (
                  <span className="hp-cmenu-item locked" role="menuitem" aria-disabled="true">{inner}</span>
                ) : (
                  <Link href={p.landingRoute as string} className="hp-cmenu-item" role="menuitem" onClick={navigate}>
                    {inner}
                  </Link>
                )}
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
