import type { Metadata } from "next";
import { OethqPageFrame } from "@/app/website/oethq-page-frame";
import { COURSE_LANDING } from "@/lib/courses-catalogue";
import { PremiumCourseLanding } from "../_components/premium-course-landing";

const copy = COURSE_LANDING["reading-listening"];

export const metadata: Metadata = {
  title: copy.metaTitle,
  description: copy.metaDescription,
  alternates: { canonical: "/courses/reading-listening" },
  openGraph: { title: copy.ogTitle, description: copy.ogDescription, url: "/courses/reading-listening", type: "website" }
};

export default function ReadingListeningCoursePage() {
  return (
    <OethqPageFrame>
      <PremiumCourseLanding slug="reading-listening" />
    </OethqPageFrame>
  );
}
