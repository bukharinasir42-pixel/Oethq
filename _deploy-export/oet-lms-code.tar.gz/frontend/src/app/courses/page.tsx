import type { Metadata } from "next";
import { OethqPageFrame } from "@/app/website/oethq-page-frame";
import { WebsitePackagesComparisonBlock } from "@/app/website/website-packages-comparison";

export const metadata: Metadata = {
  title: "Courses | OET HQ",
  description: "Choose your CBLA-calibrated clearance system — Foundation, Precision, or Elite."
};

export default function CoursesPage() {
  return (
    <OethqPageFrame>
      <WebsitePackagesComparisonBlock coursesLayout />
    </OethqPageFrame>
  );
}
