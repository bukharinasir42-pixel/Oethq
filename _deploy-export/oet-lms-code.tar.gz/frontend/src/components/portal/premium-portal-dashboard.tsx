"use client";

/**
 * PremiumPortalDashboard — candidate-portal dashboard content matching
 * 01-dashboard.html: the "route to exam day" hero, the 40-day slider, the Today
 * card, and the score-predictor / where-you-stand / your-course context cards.
 * All markup lives under the shell's `.oethq-portal` wrapper (see
 * premium-portal.css). Wired to the real dashboard/tasks/cohort data.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { cohortApi, type CohortMe } from "@/lib/cohort-api";
import { isDayPracticeComplete } from "@/lib/portal-utils";
import type { DashboardDto, TaskItem } from "@/lib/types";

const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const DAY_MS = 86_400_000;

const BANDS = [
  { to: 15, name: "Critical", c: "#E5484D" },
  { to: 30, name: "At risk", c: "#EF7A45" },
  { to: 50, name: "Developing", c: "#E9A93C" },
  { to: 70, name: "Competitive", c: "#9CBF3B" },
  { to: 85, name: "Strong", c: "#3FAE72" },
  { to: 101, name: "Excellent", c: "#1E9E5A" }
] as const;

function fmtLong(d: Date) {
  return `${d.getDate()} ${MON[d.getMonth()]} ${d.getFullYear()}`;
}

type Props = {
  profileName?: string;
  dashboard: DashboardDto | null;
  tasks: TaskItem[];
  completedTestIds: ReadonlySet<string>;
};

export function PremiumPortalDashboard({ dashboard, tasks, completedTestIds }: Props) {
  const [cohort, setCohort] = useState<CohortMe | null>(null);
  useEffect(() => {
    let active = true;
    cohortApi.me().then((c) => { if (active) setCohort(c); }).catch(() => undefined);
    return () => { active = false; };
  }, []);

  // ---- derive real values ----
  const totalDays = cohort?.schedule?.totalDays ?? 40;
  const startDate = useMemo(() => {
    if (cohort?.schedule?.startDate) return new Date(cohort.schedule.startDate);
    return null;
  }, [cohort]);
  const accessEnd = dashboard?.subscription?.endDate ? new Date(dashboard.subscription.endDate) : null;
  const completedDays = useMemo(
    () => tasks.filter((t) => isDayPracticeComplete(t, completedTestIds)).length,
    [tasks, completedTestIds]
  );
  const passProb = Math.round(dashboard?.summary?.passProbability ?? 0);
  const band = BANDS.find((b) => passProb < b.to) ?? BANDS[0];
  // Free trial: no exam pass-probability indicator.
  const isFreeTrial = dashboard?.subscription?.plan?.tier === "STARTER";
  const readingAvg = dashboard?.breakdown?.readingAverage ?? 0;
  const listeningAvg = dashboard?.breakdown?.listeningAverage ?? 0;
  const retained = dashboard?.summary?.retainedResults ?? 0;
  // Latest official OET result per skill (Rasch scaled score + grade), if any.
  const gradeLabel = (g?: string | null) => (g === "C_PLUS" ? "C+" : g || "");
  const latestReading = dashboard?.retainedResults?.find((r) => r.test.type === "READING" && r.scaledScore != null);
  const latestListening = dashboard?.retainedResults?.find((r) => r.test.type === "LISTENING" && r.scaledScore != null);
  const planName = dashboard?.subscription?.plan?.name ?? "OET Complete Course";
  const class1 = cohort?.schedule?.class1Time;
  const class2 = cohort?.schedule?.class2Time;

  const now = Date.now();
  const programmeStarted = startDate ? now >= startDate.getTime() : false;
  const currentDay = startDate
    ? Math.min(totalDays, Math.max(1, Math.floor((now - startDate.getTime()) / DAY_MS) + 1))
    : 1;
  const daysUntilStart = startDate && !programmeStarted
    ? Math.max(0, Math.ceil((startDate.getTime() - now) / DAY_MS))
    : 0;
  const todayTask = tasks.find((t) => t.dayNumber === currentDay) ?? tasks[0] ?? null;

  // ================= ROUTE (animated) =================
  const routeRef = useRef<SVGSVGElement>(null);
  useEffect(() => {
    const svg = routeRef.current;
    if (!svg) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const path = svg.querySelector<SVGPathElement>(".rt-base");
    const done = svg.querySelector<SVGPathElement>(".rt-done");
    const glow = svg.querySelector<SVGPathElement>(".rt-glow");
    const plane = svg.querySelector<SVGGElement>(".plane");
    const wps = svg.querySelector<SVGGElement>(".wps");
    if (!path || !done || !glow || !plane || !wps) return;
    const NS = "http://www.w3.org/2000/svg";
    const L = path.getTotalLength();
    const CURRENT = completedDays;
    const target = L * (CURRENT / totalDays);
    wps.innerHTML = "";
    [0, 10, 20, 30, 40].forEach((d) => {
      const at = L * (d / totalDays);
      const p = path.getPointAtLength(at);
      const past = at <= target + 0.5;
      const c = document.createElementNS(NS, "circle");
      c.setAttribute("cx", String(p.x)); c.setAttribute("cy", String(p.y));
      c.setAttribute("r", d === 0 || d === 40 ? "6" : "4.5");
      c.setAttribute("class", "wp" + (past ? " past" : ""));
      wps.appendChild(c);
      const t = document.createElementNS(NS, "text");
      t.setAttribute("x", String(p.x)); t.setAttribute("y", String(p.y + 26));
      t.setAttribute("text-anchor", "middle");
      t.setAttribute("class", "wp-t" + (past ? " past" : ""));
      t.textContent = d === 0 ? "START" : d === 40 ? "DAY 40" : "DAY " + d;
      wps.appendChild(t);
    });
    const put = (len: number) => {
      const p = path.getPointAtLength(len);
      const q = path.getPointAtLength(Math.min(len + 1, L));
      plane.setAttribute("transform", `translate(${p.x},${p.y}) rotate(${Math.atan2(q.y - p.y, q.x - p.x) * 180 / Math.PI})`);
    };
    [done, glow].forEach((el) => { el.setAttribute("stroke-dasharray", String(L)); el.setAttribute("stroke-dashoffset", String(L - target)); });
    put(Math.max(target, 0.1));
    if (reduce) return;
    [done, glow].forEach((el) => el.setAttribute("stroke-dashoffset", String(L)));
    const t0 = performance.now(); const dur = 1700;
    let raf = 0;
    const step = (t: number) => {
      const k = Math.min((t - t0) / dur, 1); const e = 1 - Math.pow(1 - k, 4);
      [done, glow].forEach((el) => el.setAttribute("stroke-dashoffset", String(L - target * e)));
      put(Math.max(target * e, 0.1));
      if (k < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [completedDays, totalDays]);

  // ================= SCORE GAUGE (animated) =================
  const gaugeRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const root = gaugeRef.current;
    if (!root) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const arc = root.querySelector<SVGPathElement>(".g-arc");
    const bloom = root.querySelector<SVGPathElement>(".g-bloom");
    const mark = root.querySelector<SVGGElement>(".g-mark");
    const valEl = root.querySelector<HTMLElement>(".g-read b");
    const bandEl = root.querySelector<HTMLElement>(".g-band");
    const ticksG = root.querySelector<SVGGElement>(".g-ticks");
    const targetG = root.querySelector<SVGGElement>(".g-target");
    const dot = root.querySelector<SVGCircleElement>(".g-dot");
    const halo = root.querySelector<SVGCircleElement>(".halo");
    const scale = root.querySelector<HTMLElement>(".g-scale");
    if (!arc || !bloom || !mark || !valEl || !bandEl || !ticksG || !targetG || !dot || !halo || !scale) return;
    const NS = "http://www.w3.org/2000/svg";
    const VALUE = passProb, TARGET = 70, CX = 120, CY = 124, R = 94;
    const gl = arc.getTotalLength();
    const pointAt = (v: number) => arc.getPointAtLength(gl * (v / 100));
    const outward = (p: DOMPoint) => ({ dx: (p.x - CX) / R, dy: (p.y - CY) / R });

    ticksG.innerHTML = "";
    for (let v = 0; v <= 100; v += 5) {
      const major = [0, 15, 30, 50, 70, 85, 100].indexOf(v) > -1;
      const p = pointAt(v); const o = outward(p); const i0 = major ? 9 : 10; const i1 = major ? 17 : 14;
      const ln = document.createElementNS(NS, "line");
      ln.setAttribute("x1", String(p.x + o.dx * i0)); ln.setAttribute("y1", String(p.y + o.dy * i0));
      ln.setAttribute("x2", String(p.x + o.dx * i1)); ln.setAttribute("y2", String(p.y + o.dy * i1));
      ln.setAttribute("class", "g-tick" + (major ? " major" : ""));
      ticksG.appendChild(ln);
    }
    targetG.innerHTML = "";
    const tp = pointAt(TARGET); const to = outward(tp);
    const tl = document.createElementNS(NS, "line");
    tl.setAttribute("x1", String(tp.x - to.dx * 8)); tl.setAttribute("y1", String(tp.y - to.dy * 8));
    tl.setAttribute("x2", String(tp.x + to.dx * 8)); tl.setAttribute("y2", String(tp.y + to.dy * 8));
    targetG.appendChild(tl);
    const tt = document.createElementNS(NS, "text");
    tt.setAttribute("x", String(tp.x + to.dx * 26)); tt.setAttribute("y", String(tp.y + to.dy * 26));
    tt.setAttribute("text-anchor", "middle"); tt.textContent = "BOOK AT 70";
    targetG.appendChild(tt);

    bandEl.style.background = band.c;
    bandEl.innerHTML = "NASIR band · " + band.name;
    dot.setAttribute("fill", band.c);
    halo.setAttribute("fill", band.c);
    bloom.setAttribute("stroke", band.c);
    valEl.style.color = band.c;

    scale.innerHTML = BANDS.map((b) => `<i style="background:${b.c}"${b.name === band.name ? ' class="on"' : ""}></i>`).join("");
    const setMark = (v: number) => { const p = pointAt(v); mark.setAttribute("transform", `translate(${p.x},${p.y})`); };
    [arc, bloom].forEach((el) => el.setAttribute("stroke-dasharray", String(gl)));

    if (reduce) {
      [arc, bloom].forEach((el) => el.setAttribute("stroke-dashoffset", String(gl - gl * (VALUE / 100))));
      setMark(VALUE); valEl.textContent = VALUE + "%";
      return;
    }
    [arc, bloom].forEach((el) => el.setAttribute("stroke-dashoffset", String(gl)));
    setMark(0);
    const s0 = performance.now(); const sdur = 1600; const delay = 260;
    let raf = 0;
    const st = (t: number) => {
      const k = Math.min(Math.max((t - s0 - delay) / sdur, 0), 1);
      const e = 1 - Math.pow(1 - k, 4);
      const reach = gl * (VALUE / 100) * e;
      [arc, bloom].forEach((el) => el.setAttribute("stroke-dashoffset", String(gl - reach)));
      setMark(VALUE * e);
      valEl.textContent = Math.round(VALUE * e) + "%";
      if (k < 1) raf = requestAnimationFrame(st);
    };
    raf = requestAnimationFrame(st);
    return () => cancelAnimationFrame(raf);
  }, [passProb, band]);

  // ================= day slider =================
  const trackRef = useRef<HTMLDivElement>(null);
  const page = (dir: number) => {
    const t = trackRef.current;
    if (t) t.scrollBy({ left: dir * t.clientWidth * 0.8, behavior: "smooth" });
  };
  const dayCards = (tasks.length ? tasks : Array.from({ length: totalDays }, (_, i) => ({ dayNumber: i + 1 } as TaskItem)))
    .slice()
    .sort((a, b) => a.dayNumber - b.dayNumber);

  return (
    <>
      {/* ============ ROUTE ============ */}
      <section className="route">
        <div className="route-head">
          <span className="caps">Your route to exam day</span>
          {accessEnd && <span className="gate"><span>Access ends</span><b>{fmtLong(accessEnd)}</b></span>}
        </div>
        <svg className="map" viewBox="0 0 1000 100" preserveAspectRatio="none" ref={routeRef} aria-label={`Programme progress, ${completedDays} of ${totalDays} days`}>
          <defs>
            <linearGradient id="trail" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#3B87F5" /><stop offset="100%" stopColor="#DCEBFF" />
            </linearGradient>
          </defs>
          <path className="rt-base" d="M22,76 C230,76 300,24 500,24 C700,24 770,76 978,76" />
          <path className="rt-glow" d="M22,76 C230,76 300,24 500,24 C700,24 770,76 978,76" />
          <path className="rt-done" d="M22,76 C230,76 300,24 500,24 C700,24 770,76 978,76" />
          <g className="wps" />
          <g className="plane">
            <circle r="19" />
            <path d="M-10,-1 L2,-1 L-1,-8 L2,-8 L9,-1 L12,-1 A1.7,1.7 0 0 1 12,2 L9,2 L2,9 L-1,9 L2,2 L-10,2 A1.7,1.7 0 0 1 -10,-1 Z" />
          </g>
        </svg>
        <div className="route-foot">
          <span className="rf">Cohort starts <b>{startDate ? `${startDate.getDate()} ${MON[startDate.getMonth()]}` : "TBC"}</b></span>
          <span className="rf"><b className="num">{completedDays}</b> of <b className="num">{totalDays}</b> days complete</span>
          <span className="rf">Class times {class1 && class2 ? <><b>{class1}</b> and <b>{class2}</b></> : <b>not set</b>}</span>
        </div>
      </section>

      {/* ============ DAY SLIDER ============ */}
      <section className="slider">
        <div className="sl-head">
          <div>
            <h2>Your {totalDays} days</h2>
            <p>{class1 && class2 ? `Live classes at ${class1} and ${class2} · change anytime` : "Set your class times to begin"}</p>
          </div>
          <div className="sl-tools">
            <Link className="btn btn-quiet" href="/portal/tasks" style={{ padding: "10px 16px", fontSize: 13 }}>Full schedule</Link>
            <button className="sl-btn" aria-label="Scroll back" onClick={() => page(-1)}><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6" /></svg></button>
            <button className="sl-btn" aria-label="Scroll forward" onClick={() => page(1)}><svg viewBox="0 0 24 24"><path d="M9 18l6-6-6-6" /></svg></button>
          </div>
        </div>
        <div className="sl-wrap">
          <div className="sl-track" ref={trackRef}>
            {dayCards.map((t) => {
              const n = t.dayNumber;
              const status = n === currentDay ? "next" : n < currentDay ? "open" : "locked";
              const dt = startDate ? new Date(startDate.getTime() + (n - 1) * DAY_MS) : null;
              return (
                <Link key={n} className={`day ${status}`} href="/portal/tasks">
                  <span className="n num">{n < 10 ? "0" : ""}{n}</span>
                  <span className="d num">{dt ? `${dt.getDate()} ${MON[dt.getMonth()]}` : "—"}</span>
                  <span className="s">
                    {status === "next" && <><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12" /></svg>Next up</>}
                    {status === "open" && "Open"}
                    {status === "locked" && <><svg viewBox="0 0 24 24"><rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V7a4 4 0 018 0v4" /></svg>Locked</>}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <div className="cols">
        {/* ============ TODAY ============ */}
        <main>
          <section className="card">
            <div className="card-head">
              <div>
                <p className="caps">Today · Day {currentDay}</p>
                <h2>{programmeStarted ? (todayTask?.title || `Day ${currentDay}`) : "Your first day opens soon"}</h2>
                <p>{programmeStarted
                  ? (todayTask?.summary || "Your live classes and timed tests for today are below.")
                  : `Everything unlocks when your cohort begins${class1 ? ` at ${class1}` : ""}.`}</p>
              </div>
              <span className={`pill ${programmeStarted ? "pill-open" : ""}`}><i />{programmeStarted ? "Open" : "Soon"}</span>
            </div>

            {programmeStarted && todayTask ? (
              <ul className="legs">
                <li className="now">
                  <span className="leg-t"><b>{todayTask.lectureTitle || "Day lecture"}</b><span>Live class 1 of 2</span></span>
                  <span className="leg-r"><b>{class1 || "—"}</b><span>Today</span></span>
                </li>
                <li>
                  <span className="leg-t"><b>{todayTask.articleTitle || "Day article"}</b><span>Live class 2 of 2</span></span>
                  <span className="leg-r"><b>{class2 || "—"}</b><span>Today</span></span>
                </li>
                <li>
                  <span className="leg-t"><b>Reading test</b><span>Parts A, B and C · 42 questions</span></span>
                  <span className="leg-r"><b>60 min</b><span>Timed</span></span>
                </li>
                <li>
                  <span className="leg-t"><b>Listening test</b><span>Parts A, B and C · 42 questions</span></span>
                  <span className="leg-r"><b>50 min</b><span>Timed</span></span>
                </li>
              </ul>
            ) : (
              <div className="pending">
                <span className="pending-ico"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 11h18" /></svg></span>
                <div>
                  <b>Nothing to do today</b>
                  <p>A reminder email arrives 30 minutes before each class. Miss one and the recording appears in its place.</p>
                </div>
                {daysUntilStart > 0 && <span className="when"><b className="num">{daysUntilStart} day{daysUntilStart === 1 ? "" : "s"}</b><span>until Day 1</span></span>}
              </div>
            )}

            <div className="card-foot">
              <Link className="btn btn-primary" href="/portal/tasks">Open today <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" /></svg></Link>
              <Link className="btn btn-quiet" href="/portal/tasks">See the {totalDays}-day plan</Link>
              <p>Or start a timed test now to set your baseline</p>
            </div>
          </section>
        </main>

        {/* ============ CONTEXT RAIL ============ */}
        <aside className="ctx">
          {!isFreeTrial && (
          <section className="card card-pad" ref={gaugeRef}>
            <p className="caps">Score predictor</p>
            <div className="gauge">
              <svg viewBox="0 0 240 152" aria-label={`Pass probability ${passProb} percent, band ${band.name}`}>
                <defs>
                  <linearGradient id="bandgrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#E5484D" /><stop offset="22%" stopColor="#EF7A45" />
                    <stop offset="44%" stopColor="#E9A93C" /><stop offset="64%" stopColor="#9CBF3B" />
                    <stop offset="84%" stopColor="#3FAE72" /><stop offset="100%" stopColor="#1E9E5A" />
                  </linearGradient>
                </defs>
                <g className="g-ticks" />
                <path className="g-track" d="M26,124 A94,94 0 0 1 214,124" />
                <path className="g-bloom" d="M26,124 A94,94 0 0 1 214,124" />
                <path className="g-arc" d="M26,124 A94,94 0 0 1 214,124" />
                <g className="g-target" />
                <g className="g-mark">
                  <circle className="halo" r="17" />
                  <circle className="ring" r="10.5" />
                  <circle className="g-dot" r="5.5" />
                </g>
              </svg>
              <div className="g-read"><b className="num">0%</b><span>Pass probability</span></div>
            </div>
            <span className="g-band">NASIR band · {band.name}</span>
            <div className="g-scale" />
            <div className="g-legend"><span>Critical</span><span>Excellent</span></div>
            <p className="note" style={{ margin: "16px 0 0", fontSize: 12.5, lineHeight: 1.55, color: "var(--mute)" }}>
              Based on {retained} retained result{retained === 1 ? "" : "s"}. More timed tests make this reading reliable.
            </p>
            <Link className="more" href="/portal/dashboard">Open progress <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" /></svg></Link>
          </section>
          )}

          <section className="card card-pad">
            <h3>Where you stand</h3>
            <div className="mini">
              <span className="mini-ico"><svg viewBox="0 0 24 24"><path d="M2 4h7a3 3 0 013 3v13a2.5 2.5 0 00-2.5-2.5H2z" /><path d="M22 4h-7a3 3 0 00-3 3v13a2.5 2.5 0 012.5-2.5H22z" /></svg></span>
              <span className="mini-t"><b>Reading</b><span>{latestReading ? `Grade ${gradeLabel(latestReading.oetGrade)} · latest scaled` : (readingAvg > 0 ? "Raw average" : "No attempt yet")}</span></span>
              <span className="mini-v num">{latestReading ? latestReading.scaledScore : (readingAvg > 0 ? readingAvg : "—")}</span>
            </div>
            <div className="mini">
              <span className="mini-ico"><svg viewBox="0 0 24 24"><path d="M3 17v-5a9 9 0 0118 0v5" /><path d="M21 18a2 2 0 01-2 2h-1v-6h1a2 2 0 012 2zM3 18a2 2 0 002 2h1v-6H5a2 2 0 00-2 2z" /></svg></span>
              <span className="mini-t"><b>Listening</b><span>{latestListening ? `Grade ${gradeLabel(latestListening.oetGrade)} · latest scaled` : (listeningAvg > 0 ? "Raw average" : "No attempt yet")}</span></span>
              <span className="mini-v num">{latestListening ? latestListening.scaledScore : (listeningAvg > 0 ? listeningAvg : "—")}</span>
            </div>
            <div className="mini">
              <span className="mini-ico"><svg viewBox="0 0 24 24"><path d="M8 21h8M12 17v4" /><path d="M17 4h3v4a5 5 0 01-5 5H9a5 5 0 01-5-5V4h3z" /></svg></span>
              <span className="mini-t"><b>Papers completed</b><span>Of {totalDays} in your plan</span></span>
              <span className="mini-v num">{retained}</span>
            </div>
            <Link className="more" href="/portal/results">Open results <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" /></svg></Link>
          </section>

          <section className="card card-pad">
            <p className="caps">Your course</p>
            <div className="course">
              <span className="course-ico"><svg viewBox="0 0 24 24"><path d="M22 10L12 5 2 10l10 5 10-5z" /><path d="M6 12v5c0 1.7 2.7 3 6 3s6-1.3 6-3v-5" /></svg></span>
              <div>
                <b>{planName}</b>
                <p>Reading, Listening, Writing and Speaking</p>
                {accessEnd && <span className="owned">Owned until {fmtLong(accessEnd)}</span>}
              </div>
            </div>
            <Link className="more" href="/courses">Browse all courses <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" /></svg></Link>
          </section>
        </aside>
      </div>
    </>
  );
}
