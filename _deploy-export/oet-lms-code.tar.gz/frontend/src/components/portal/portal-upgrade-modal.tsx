"use client";

/**
 * PortalUpgradeModal — picks the right upgrade prompt for a locked portal item.
 * Free-trial users see the flagship plans modal (the whole Complete Course /
 * standalone pricing), everyone else sees the focused per-skill upgrade card.
 */
import { WebsiteUpgradePlansModal } from "@/app/website/website-packages-comparison";
import { SkillUpgradeModal } from "@/components/portal/skill-upgrade-modal";
import type { SkillKey } from "@/hooks/use-ownership";

type Props = {
  isFreeTrial: boolean;
  skill: SkillKey | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
};

export function PortalUpgradeModal({ isFreeTrial, skill, open, onOpenChange }: Props) {
  if (isFreeTrial) {
    return <WebsiteUpgradePlansModal open={open} onOpenChange={onOpenChange} />;
  }
  return <SkillUpgradeModal skill={open ? skill : null} open={open} onOpenChange={onOpenChange} />;
}
