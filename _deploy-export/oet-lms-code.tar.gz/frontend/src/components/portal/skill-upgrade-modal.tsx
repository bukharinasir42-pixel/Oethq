"use client";

/**
 * SkillUpgradeModal — shown when a user clicks a LOCKED skill in the portal.
 * Two sections (per the approved design): the standalone courses that would
 * unlock this skill, AND the Complete Course option. Data from the live catalogue.
 */
import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight, GraduationCap, Lock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { productsApi, type CatalogueProduct } from "@/lib/products-api";
import type { SkillKey } from "@/hooks/use-ownership";

const SKILL_LABEL: Record<SkillKey, string> = {
  READING: "Reading", LISTENING: "Listening", WRITING: "Writing", SPEAKING: "Speaking"
};

export function SkillUpgradeModal({
  skill, open, onOpenChange
}: { skill: SkillKey | null; open: boolean; onOpenChange: (v: boolean) => void }) {
  const [products, setProducts] = useState<CatalogueProduct[]>([]);

  useEffect(() => {
    if (!open) return;
    let active = true;
    productsApi.list().then((r) => { if (active) setProducts(r.products); }).catch(() => undefined);
    return () => { active = false; };
  }, [open]);

  const label = skill ? SKILL_LABEL[skill] : "this skill";
  const unlocking = products.filter(
    (p) => p.category === "STANDALONE" && p.status === "ACTIVE" && p.isPurchasable && skill && p.includedSkills.includes(skill)
  );
  const complete = products.find((p) => p.category === "COMPLETE");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Lock className="h-4 w-4 text-primary" aria-hidden /> Unlock {label}
          </DialogTitle>
        </DialogHeader>

        <p className="text-sm text-muted-foreground">
          {label} lectures, tests and past papers aren&apos;t part of your current plan. Add {label} on its own,
          or go all-in with a Complete Course.
        </p>

        {unlocking.length > 0 && (
          <div className="mt-2">
            <p className="mb-2 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">Add {label}</p>
            <div className="space-y-2">
              {unlocking.map((p) => (
                <Link
                  key={p.slug}
                  href={p.landingRoute ?? "/courses"}
                  onClick={() => onOpenChange(false)}
                  className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card p-3 transition hover:border-primary/40 hover:bg-primary/[0.04]"
                >
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-semibold text-foreground">{p.name}</span>
                    <span className="block text-xs text-muted-foreground">{p.priceLabel}</span>
                  </span>
                  <ArrowRight className="h-4 w-4 shrink-0 text-primary" aria-hidden />
                </Link>
              ))}
            </div>
          </div>
        )}

        {complete && (
          <div className="mt-3">
            <p className="mb-2 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">Or go all-in</p>
            <Link
              href="/courses"
              onClick={() => onOpenChange(false)}
              className="flex items-center justify-between gap-3 rounded-xl border border-primary/25 bg-gradient-to-r from-[#0A3060] to-[#1465C8] p-4 text-white transition hover:brightness-110"
            >
              <span className="flex items-center gap-3">
                <GraduationCap className="h-6 w-6 shrink-0" aria-hidden />
                <span>
                  <span className="block text-sm font-bold">{complete.name}</span>
                  <span className="block text-xs text-white/80">All four skills — Foundation, Precision or Elite.</span>
                </span>
              </span>
              <ArrowRight className="h-4 w-4 shrink-0" aria-hidden />
            </Link>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
