"use client";

import { useEffect, useState } from "react";
import { useSession } from "@/hooks/use-session";
import { apiFetch } from "@/lib/api";
import { hasPastPaperPortalAccess } from "@/lib/portal-past-paper-utils";
import { productsApi, type Ownership } from "@/lib/products-api";
import type { SkillKey } from "@/hooks/use-ownership";
import type { PlanDto } from "@/lib/types";

type SubscriptionStatusDto = {
  status: string;
  plan?: PlanDto | null;
  expiresInDays?: number;
  requiresPlanActivation?: boolean;
  activationUrl?: string | null;
  accessGranted?: boolean;
  accessExpired?: boolean;
};

export function usePortalPlanAccess() {
  const { token, profile } = useSession();
  const [subscription, setSubscription] = useState<SubscriptionStatusDto | null>(null);
  const [ownership, setOwnership] = useState<Ownership | null>(null);
  const [loading, setLoading] = useState(true);
  // `loaded` is true ONLY after a real fetch has resolved for the current user.
  // Consumers must gate access decisions on this (not `loading`), because on a
  // hard page load `loading` briefly reads false while the session is still
  // resolving the token — which would otherwise trip premature redirects.
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!token || !profile) {
      setSubscription(null);
      setOwnership(null);
      setLoading(false);
      setLoaded(false);
      return;
    }

    let cancelled = false;
    setLoading(true);
    setLoaded(false);

    void Promise.all([
      apiFetch<SubscriptionStatusDto>(`/subscriptions/status?userId=${encodeURIComponent(profile.id)}`, { token })
        .catch(() => null),
      productsApi.ownership().catch(() => null)
    ])
      .then(([sub, own]) => {
        if (cancelled) return;
        setSubscription(sub);
        setOwnership(own);
      })
      .finally(() => {
        if (!cancelled) {
          setLoading(false);
          setLoaded(true);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [profile, token]);

  const planTier = subscription?.plan?.tier ?? null;
  const pastPaperLimit = subscription?.plan?.pastPaperLimit ?? 0;

  const ownedSkills = (ownership?.ownedSkills as SkillKey[]) ?? [];
  const entitlementKeys = ownership?.entitlementKeys ?? [];
  // A standalone/add-on product entitlement (anything other than the Complete
  // Course, which is derived from the subscription).
  const hasProductEntitlement = entitlementKeys.some((k) => k !== "complete");

  const requiresPlanActivation = Boolean(subscription?.requiresPlanActivation);
  const accessExpired =
    subscription?.accessExpired === true ||
    subscription?.status === "EXPIRED" ||
    ((subscription?.status === "ACTIVE" || subscription?.status === "TRIAL") &&
      (subscription.expiresInDays ?? 0) <= 0 &&
      Boolean(subscription.plan) &&
      !requiresPlanActivation);
  const subscriptionAccessGranted =
    subscription?.accessGranted === true ||
    ((subscription?.expiresInDays ?? 0) > 0 &&
      (subscription?.status === "ACTIVE" || subscription?.status === "TRIAL") &&
      !accessExpired);

  // Portal access is granted by an active subscription OR any owned product.
  const accessGranted = Boolean(subscriptionAccessGranted) || hasProductEntitlement;

  // The "Complete Course experience" = cohort live classes + the daily study-plan
  // journey. Granted by any active subscription (a paid Complete plan OR a free
  // trial preview). Standalone-only buyers (no active subscription) DON'T get it,
  // so cohort + study plan lock for them. See standalone-vs-complete-portal-scope.
  const completeExperienceAccess = Boolean(subscriptionAccessGranted);
  // Owns the paid Complete Course specifically (not just a free-trial preview).
  const hasCompleteCourse =
    (Boolean(subscriptionAccessGranted) && planTier !== null && planTier !== "STARTER") ||
    entitlementKeys.includes("complete");

  // Past papers nav: existing Complete-plan rule OR owning a course that includes
  // Reading or Listening (both include past papers).
  const showPastPapersNav =
    hasPastPaperPortalAccess(planTier, pastPaperLimit) ||
    ownedSkills.includes("READING") ||
    ownedSkills.includes("LISTENING");

  return {
    subscription,
    planTier,
    pastPaperLimit,
    ownedSkills,
    entitlementKeys,
    hasProductEntitlement,
    ownsSkill: (s: SkillKey) => ownedSkills.includes(s),
    showPastPapersNav,
    requiresPlanActivation,
    accessExpired: Boolean(accessExpired),
    accessGranted,
    completeExperienceAccess,
    hasCompleteCourse,
    loading,
    loaded
  };
}
