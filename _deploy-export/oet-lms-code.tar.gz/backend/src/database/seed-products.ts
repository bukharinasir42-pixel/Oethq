/**
 * seed-products.ts — the authoritative course catalogue (Product rows).
 *
 * Single source of truth for the Courses dropdown, homepage catalogue, landing
 * pages, checkout mapping and entitlement mapping. Complete Course stays on the
 * existing Plan/Subscription system and is represented here only as a catalogue
 * entry that links back to the existing /courses experience (it is NOT purchased
 * as a standalone Product).
 *
 * ⚠️ PLACEHOLDER COMMERCIAL VALUES: `price` and `durationDays` on the standalone
 * courses below are PLACEHOLDERS pending real numbers. Replace them (here or via
 * an admin update) before going live. Locked (coming-soon) products carry no
 * price and are never purchasable.
 */
import "../load-env";
import { Prisma, PrismaClient, ProductCategory, ProductStatus } from "@prisma/client";

const asJson = (v: Record<string, unknown> | null): Prisma.InputJsonValue | undefined =>
  v == null ? undefined : (v as Prisma.InputJsonValue);

const prisma = new PrismaClient();

type SeedProduct = {
  slug: string;
  name: string;
  category: ProductCategory;
  status: ProductStatus;
  displayOrder: number;
  shortDescription: string;
  landingRoute: string | null;
  price: number | null;
  durationDays: number | null;
  includedSkills: string[];
  includedModules: Record<string, unknown> | null;
  entitlementKey: string;
  isPurchasable: boolean;
  featured: boolean;
  upgradeOfSlug: string | null;
  writingCorrections?: number;
};

const PRODUCTS: SeedProduct[] = [
  {
    slug: "complete",
    name: "OET Complete Courses",
    category: ProductCategory.COMPLETE,
    status: ProductStatus.ACTIVE,
    displayOrder: 0,
    shortDescription: "Full OET preparation — all four skills, past papers, corrections and analytics.",
    landingRoute: "/courses", // existing Complete Course experience (Foundation / Precision / Elite)
    price: null, // priced by the existing Plan tiers, not as a standalone product
    durationDays: null,
    includedSkills: ["READING", "LISTENING", "WRITING", "SPEAKING"],
    includedModules: { note: "See the Foundation / Precision / Elite packages on /courses." },
    entitlementKey: "complete",
    isPurchasable: false, // purchased via the existing plan checkout, never as a Product
    featured: true,
    upgradeOfSlug: null
  },
  {
    slug: "reading-listening",
    name: "OET Reading & Listening Course",
    category: ProductCategory.STANDALONE,
    status: ProductStatus.ACTIVE,
    displayOrder: 1,
    shortDescription: "Master the two receptive skills — lectures, practice + mock tests, OET HQ past papers and progress reports for Reading and Listening.",
    landingRoute: "/courses/reading-listening",
    price: 149, // ⚠️ PLACEHOLDER — replace with real price
    durationDays: 60, // ⚠️ PLACEHOLDER — replace with real access duration
    includedSkills: ["READING", "LISTENING"],
    includedModules: {
      reading: ["Lectures", "Practice tests", "Mock tests", "OET HQ past papers", "Progress report"],
      listening: ["Lectures", "Practice tests", "Mock tests", "OET HQ past papers", "Progress report"]
    },
    entitlementKey: "reading_listening",
    isPurchasable: true,
    featured: true,
    upgradeOfSlug: null
  },
  {
    slug: "reading",
    name: "OET Reading Course",
    category: ProductCategory.STANDALONE,
    status: ProductStatus.ACTIVE,
    displayOrder: 2,
    shortDescription: "Focused Reading preparation — Part A/B/C strategy, practice + mock tests, OET HQ past papers and a Reading progress report.",
    landingRoute: "/courses/reading",
    price: 99, // ⚠️ PLACEHOLDER — replace with real price
    durationDays: 60, // ⚠️ PLACEHOLDER
    includedSkills: ["READING"],
    includedModules: { reading: ["Lectures", "Practice tests", "Mock tests", "OET HQ past papers", "Progress report"] },
    entitlementKey: "reading",
    isPurchasable: true,
    featured: false,
    upgradeOfSlug: "reading-listening"
  },
  {
    slug: "listening",
    name: "OET Listening Course",
    category: ProductCategory.STANDALONE,
    status: ProductStatus.ACTIVE,
    displayOrder: 3,
    shortDescription: "Focused Listening preparation — Part A/B/C strategy, practice + mock tests, OET HQ past papers and a Listening progress report.",
    landingRoute: "/courses/listening",
    price: 99, // ⚠️ PLACEHOLDER — replace with real price
    durationDays: 60, // ⚠️ PLACEHOLDER
    includedSkills: ["LISTENING"],
    includedModules: { listening: ["Lectures", "Practice tests", "Mock tests", "OET HQ past papers", "Progress report"] },
    entitlementKey: "listening",
    isPurchasable: true,
    featured: false,
    upgradeOfSlug: "reading-listening"
  },
  {
    slug: "writing-corrections-2",
    name: "Writing Corrections — 2 Letters",
    category: ProductCategory.ADDON,
    status: ProductStatus.ACTIVE,
    displayOrder: 40,
    shortDescription: "2 letters marked to official OET Writing criteria.",
    landingRoute: "/courses/writing-corrections",
    price: 28,
    durationDays: 120,
    includedSkills: ["WRITING"],
    includedModules: null,
    entitlementKey: "writing_corrections_2",
    isPurchasable: true,
    featured: false,
    upgradeOfSlug: null,
    writingCorrections: 2
  },
  {
    slug: "writing-corrections-6",
    name: "Writing Corrections — 6 Letters",
    category: ProductCategory.ADDON,
    status: ProductStatus.ACTIVE,
    displayOrder: 41,
    shortDescription: "6 letters marked to official OET Writing criteria.",
    landingRoute: "/courses/writing-corrections",
    price: 77,
    durationDays: 120,
    includedSkills: ["WRITING"],
    includedModules: null,
    entitlementKey: "writing_corrections_6",
    isPurchasable: true,
    featured: true,
    upgradeOfSlug: null,
    writingCorrections: 6
  },
  {
    slug: "writing-corrections-12",
    name: "Writing Corrections — 12 Letters",
    category: ProductCategory.ADDON,
    status: ProductStatus.ACTIVE,
    displayOrder: 42,
    shortDescription: "12 letters marked to official OET Writing criteria.",
    landingRoute: "/courses/writing-corrections",
    price: 147,
    durationDays: 120,
    includedSkills: ["WRITING"],
    includedModules: null,
    entitlementKey: "writing_corrections_12",
    isPurchasable: true,
    featured: false,
    upgradeOfSlug: null,
    writingCorrections: 12
  },
  {
    slug: "speaking-role-plays",
    name: "OET Speaking Role Plays",
    category: ProductCategory.ADDON,
    status: ProductStatus.COMING_SOON,
    displayOrder: 5,
    shortDescription: "Guided speaking role-play practice with structured feedback.",
    landingRoute: null,
    price: null,
    durationDays: null,
    includedSkills: ["SPEAKING"],
    includedModules: null,
    entitlementKey: "speaking_role_plays",
    isPurchasable: false, // locked
    featured: false,
    upgradeOfSlug: null
  }
];

async function main() {
  for (const p of PRODUCTS) {
    await prisma.product.upsert({
      where: { slug: p.slug },
      create: {
        slug: p.slug,
        name: p.name,
        category: p.category,
        status: p.status,
        displayOrder: p.displayOrder,
        shortDescription: p.shortDescription,
        landingRoute: p.landingRoute,
        price: p.price ?? undefined,
        durationDays: p.durationDays ?? undefined,
        includedSkills: p.includedSkills,
        includedModules: asJson(p.includedModules),
        entitlementKey: p.entitlementKey,
        isPurchasable: p.isPurchasable,
        featured: p.featured,
        upgradeOfSlug: p.upgradeOfSlug,
        writingCorrections: p.writingCorrections ?? 0
      },
      // Never override commercial fields once set by an admin except status/order/copy.
      update: {
        name: p.name,
        category: p.category,
        status: p.status,
        displayOrder: p.displayOrder,
        shortDescription: p.shortDescription,
        landingRoute: p.landingRoute,
        includedSkills: p.includedSkills,
        includedModules: asJson(p.includedModules),
        entitlementKey: p.entitlementKey,
        isPurchasable: p.isPurchasable,
        featured: p.featured,
        upgradeOfSlug: p.upgradeOfSlug,
        writingCorrections: p.writingCorrections ?? 0
      }
    });
    // eslint-disable-next-line no-console
    console.log(`  product upserted: ${p.slug} (${p.status})`);
  }
  // eslint-disable-next-line no-console
  console.log("Product catalogue seeded.");
}

main()
  .catch((e) => {
    // eslint-disable-next-line no-console
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
