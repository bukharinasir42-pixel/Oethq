/**
 * Free-trial (STARTER) access rules. A trial user owns no skills, so instead of
 * skill-ownership we grant exactly ONE sample of each: the first published
 * lecture, the first published Reading test and the first published Listening
 * test. Everything else stays locked → upgrade. Spelling and the Part A drill
 * are allowed on the practice surface (frontend-gated, no backend ownership).
 */
import { PlanTier, SubscriptionStatus, TestType, Prisma } from "@prisma/client";
import type { PrismaService } from "../../common/prisma.service";

export type TrialAccess = {
  isTrial: boolean;
  lectureId: string | null;
  readingTestId: string | null;
  listeningTestId: string | null;
};

const NOT_NULL_JSON = { NOT: { contentJson: { equals: Prisma.DbNull } } };

export async function resolveTrialAccess(prisma: PrismaService, userId: string): Promise<TrialAccess> {
  const now = new Date();
  const subs = await prisma.subscription.findMany({
    where: { userId, status: { in: [SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIAL] } },
    select: { endDate: true, plan: { select: { tier: true } } }
  });
  const active = subs.filter((s) => !s.endDate || s.endDate > now);
  const hasPaid = active.some((s) => s.plan.tier !== PlanTier.STARTER);
  const isTrial = !hasPaid && active.some((s) => s.plan.tier === PlanTier.STARTER);
  if (!isTrial) return { isTrial: false, lectureId: null, readingTestId: null, listeningTestId: null };

  const [lecture, reading, listening] = await Promise.all([
    prisma.courseLecture.findFirst({ where: { isPublished: true }, orderBy: [{ displayOrder: "asc" }, { createdAt: "asc" }], select: { id: true } }),
    prisma.test.findFirst({ where: { type: TestType.READING, isPublished: true, ...NOT_NULL_JSON }, orderBy: { createdAt: "asc" }, select: { id: true } }),
    prisma.test.findFirst({ where: { type: TestType.LISTENING, isPublished: true, ...NOT_NULL_JSON }, orderBy: { createdAt: "asc" }, select: { id: true } })
  ]);
  return { isTrial: true, lectureId: lecture?.id ?? null, readingTestId: reading?.id ?? null, listeningTestId: listening?.id ?? null };
}
